/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package comparacao;

public class Carneiro extends Animal{
    public Carneiro(){
        this.nome = "Banabé";
        this.numeroPatas = 4;
        
    }
    
    @Override
    public void som(){
        System.out.print("BÉÉÉ");
    }
}