/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package comparacao;

public class Zoo {

    public static void main2( String[] args) {
        Vaca mimosa = new Vaca();
        Gato bichano = new Gato();
        Carneiro barnabe = new Carneiro();

        Animal bichos[] = {mimosa, bichano, barnabe};
        
        
        
        for(int i=0 ; i < bichos.length ; i++)
        {
                if(bichos[i] instanceof Vaca){
                    System.out.print("A vaca tem " + bichos[i].numeroPatas + " patas e faz ");
                    bichos[i].som();
                    System.out.println();
                }
                
                if(bichos[i] instanceof Gato){
                    System.out.print("O gato tem " + bichos[i].numeroPatas + " patas e faz ");
                    bichos[i].som();
                    System.out.println();
                }
                
                if(bichos[i] instanceof Carneiro){
                    System.out.print("O carneiro tem " + bichos[i].numeroPatas + " patas e faz ");
                    bichos[i].som();
                    System.out.println();
                }
        }
    }

}
